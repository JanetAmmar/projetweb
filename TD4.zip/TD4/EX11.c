#include <stdio.h>
#define taille 100
int main()
{
      int n,i;
      const int taille100;
      float T[taille],somme,moy,max;

      do{
              printf("Donner la taille du tableau (<=100) : ");
              scanf("%d",&n);
      }while 
}