from random import randint
nom=input("Entrez le nom de l'étudiant: ")
note1=float(input("Entrez la 1ere  note de l'étudiant: "))
note2=float(input("Entrez la 2eme note de l'étudiant: "))
while note1<0 or note1>20 and note2<0 or note2>20:
    print("Erreur: les notes doivent être entre 0 et 20.")
    note1=float(input("Entrez la 1ere  note de l'étudiant: "))
    note2=float(input("Entrez la 2eme note de l'étudiant: "))
moyenne=(note1+note2)/2
print("La moyenne de l'étudiant", nom, "est de:", moyenne)
    
bonus=randint(5,20)
print("L'étudiant", nom, "a reçu un bonus de:", bonus, "%")
notefinale=moyenne*(1+(bonus/100))
print("La note finale de l'étudiant", nom, "est de:", notefinale) 