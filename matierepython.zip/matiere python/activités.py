
legumes = ["Tomate", "Carotte", "Poivron", "Courgette"]
prix = [2.5, 1.8, 3.0, 2.2]  

tva = lambda p: p * 1.05
prix_tva = list(map(tva, prix))
print("Prix TVA :", prix_tva)