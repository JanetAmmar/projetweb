# Panier de fruits (dictionnaire vide au départ)
panier = {}

# 1) Afficher le panier
def afficher_panier():
    if not panier:
        print("Le panier est vide.")
    else:
        print("Contenu du panier :")
        for fruit, qte in panier.items():
            print(f"- {fruit} : {qte}")

# 2) Ajouter un fruit (quantité par défaut = 1)
def ajouter_fruit(fruit, quantite=1):
    if fruit in panier:
        panier[fruit] += quantite
    else:
        panier[fruit] = quantite
    print(f"{quantite} {fruit} ajouté(s).")

# 3) Vérifier la quantité d’un fruit
def quantite_fruit(fruit):
    if fruit in panier:
        return fruit, panier[fruit]
    else:
        return fruit, 0

# 4) Ajouter plusieurs fruits à la fois
def ajouter_plusieurs_fruits(fruits):
    # fruits : dictionnaire ex {"pomme": 3, "orange": 2}
    for fruit, qte in fruits.items():
        ajouter_fruit(fruit, qte)

# 5) Calculer le montant total du panier
def montant_total(prix_fruits):
    total = 0
    for fruit, qte in panier.items():
        if fruit in prix_fruits:
            total += prix_fruits[fruit] * qte
        else:
            print(f"⚠️ Prix de {fruit} non trouvé !")
    return total


# -------------------------
# Exemple d'utilisation :
# -------------------------

afficher_panier()

ajouter_fruit("pomme", 2)
ajouter_fruit("banane")  # quantité par défaut = 1

afficher_panier()

nom, qte = quantite_fruit("pomme")
print(f"\nQuantité de {nom} : {qte}")

ajouter_plusieurs_fruits({"orange": 4, "fraise": 10})

afficher_panier()

# Prix unitaires
prix = {"pomme": 1.5, "banane": 1.2, "orange": 2, "fraise": 0.5}

total = montant_total(prix)
print(f"\nMontant total du panier : {total} dt")
